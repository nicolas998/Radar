# Radar
Python tools for the procces of radar images, contains classification tools, image analysis tools and Z to Rain conversion, tested for the Aburra Valley located in Medellín, Colombia
